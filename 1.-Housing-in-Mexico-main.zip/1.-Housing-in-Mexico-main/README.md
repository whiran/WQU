# Project-on-Housing-in-Mexico-main
How to organize information using basic Python data structures.
How to import data from CSV files and clean it using the pandas library.
How to create data visualizations like scatter and box plots.
How to examine the relationship between two variables using correlation.
