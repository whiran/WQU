# Air-Quality-in-Nairobi
How to get data by querying a MongoDB database.
How to prepare time series data for analysis.
How to build an autoregression model.
How to improve a model by tuning its hyperparameters.
