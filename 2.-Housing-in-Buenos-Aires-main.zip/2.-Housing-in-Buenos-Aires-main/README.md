# Project-on-Predicting-Housing-Prices-in-Buenos-Aires-Argentina-main
How to create a linear regression model using the scikit-learn library.
How to build a data pipeline for imputing missing values and encoding categorical features.
How to improve model performance by reducing overfitting.
How to create a dynamic dashboard for interacting with your completed model.
